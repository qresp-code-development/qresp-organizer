# -*- coding: utf-8 -*-
 
 
"""qresp_config.__main__: executed when qresp_config directory is called as script."""
 
 
from .qresp_config import main
main()